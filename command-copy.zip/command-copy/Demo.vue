// 如何使用？
// 1、使用之前记得引入第三方包VueClipboard，在main.js中Vue.use(VueClipboard);
// 2、在需要引用的组件中引入弹框组件,并且为弹框组件绑定一个close事件，用于关闭弹框
// 弹框组件可传三个参数copySuccessText、copyMessage、clstag
// copySuccessText为‘复制成功后弹出的提示信息’（非必须，如不传则为‘’）
// copyMessage为‘复制到剪切板上的信息’（非必须，如不传则为‘’）
// clstag为‘点击去微信粘贴好友的埋点信息’（非必须）
// 假设在APP.vue引入command-copy组件
<template>
  <command-copy @close="closeModal" v-if="isshow" />
</template>

<script>
  import commandCopy from '../components/command-copy/command-copy';
  export default {
    data() {
      return {
        isshow: false
      }
    },
    components: {
      commandCopy
    },
    methods: {
      closeModal: function() { // close事件所对应的方法，点击‘弹框的右上角X’和‘点击去微信粘贴好友’时触发
        this.isshow = false;
      },
    }
  }
</script>

