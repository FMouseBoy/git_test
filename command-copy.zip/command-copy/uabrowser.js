/* eslint-disable radix */
/* @flow */
const uabrowser = {};
const ua = window.navigator.userAgent;
const uaLower = ua.toLowerCase();
// eslint-disable-next-line no-useless-escape
const android = ua.match(/(Android);?[\s\/]+([\d.]+)?/);
const ipad = ua.match(/(iPad).*OS\s([\d_]+)/);
const ipod = ua.match(/(iPod)(.*OS\s([\d_]+))?/);
const iphone = !ipad && ua.match(/(iPhone\sOS)\s([\d_]+)/);

// eslint-disable-next-line no-multi-assign
uabrowser.ios = uabrowser.android = uabrowser.iphone = uabrowser.ipad = uabrowser.androidChrome = false;

// Android
if (android) {
  uabrowser.os = 'android';
  try {
    // eslint-disable-next-line prefer-destructuring
    uabrowser.osVersion = android[2];
  } catch (error) {
    console.log(error);
  }
  uabrowser.android = true;
  uabrowser.androidChrome = uaLower.indexOf('chrome') >= 0;
}

if (ipad || iphone || ipod) {
  uabrowser.os = 'ios';
  uabrowser.ios = true;
}

// iOS
if (iphone && !ipod) {
  try {
    uabrowser.osVersion = iphone[2].replace(/_/g, '.');
  } catch (error) {
    console.log(error);
  }
  uabrowser.iphone = true;
}

if (ipad) {
  try {
    uabrowser.osVersion = ipad[2].replace(/_/g, '.');
  } catch (error) {
    console.log(error);
  }
  uabrowser.ipad = true;
}

if (ipod) {
  try {
    uabrowser.osVersion = ipod[3] ? ipod[3].replace(/_/g, '.') : null;
  } catch (error) {
    console.log(error);
  }
  uabrowser.iphone = true;
}

try {
  // iOS 8+ changed UA
  if (uabrowser.ios && uabrowser.osVersion && ua.indexOf('Version/') >= 0) {
    if (uabrowser.osVersion.split('.')[0] === '10') {
      // eslint-disable-next-line prefer-destructuring
      uabrowser.osVersion = ua
        .toLowerCase()
        .split('version/')[1]
        .split(' ')[0];
    }
  }
} catch (error) {
  console.log(error);
}

// Add html classes
ua.split('&').forEach(function(key) {
  if (typeof key === 'string' && key) {
    // console.log(key);
    const keys = key.split('=');
    if (keys && keys.length > 1 && keys[0] && keys[1]) {
      // eslint-disable-next-line prefer-destructuring
      uabrowser[keys[0]] = keys[1];
    }
  }
});

// 微信
uabrowser.weixin = /micromessenger/i.test(uaLower);

// 金融app老年版
uabrowser.jdjrOld = /jdjr-app-aged/.test(uaLower);
// 金融app内的开普勒
uabrowser.kepler = /keplerm=keplerm/.test(uaLower);
// 金融app 排除开普勒和老年版
uabrowser.jdjr = !uabrowser.kepler && !uabrowser.jdjrOld && /jdjr-app/.test(uaLower);
// 金融app 包含开普勒和老年版
uabrowser.jdjrPure = /jdjr-app/.test(uaLower);
// 金融app特有
uabrowser.jdjrios = /ios/.test(uaLower);
// 金融app特有
uabrowser.isupdate = /isupdate/.test(uaLower);

// 商城ipad app
uabrowser.jdPadApp = /jdapp;ipad;/.test(uaLower);
// 商城app
uabrowser.jdapp = /jdapp/.test(uaLower) && !uabrowser.jdPadApp;

// 钱包app
uabrowser.wallet = /walletclient/.test(uaLower);

// 京东到家
uabrowser.jdlocal = /jdlocal/.test(uaLower);

// qq
uabrowser.qq = /qq/.test(uaLower);

// 京东支付SDK
uabrowser.jdPaySDK = /jdpaysdk/.test(uaLower);

// 7freshapp
uabrowser.freshApp = /7freshapp/.test(uaLower);

/**
 * 兼容ios 和 android 命名不规则的问题
 * @type {[type]}
 */
uabrowser.clientType = uabrowser.clientType || uabrowser.os;
uabrowser.clientVersion = uabrowser.clientVersion || uabrowser.version || '';

/**
 * 判断商城版本号
 * @param {int} a
 * @param {int} b
 * @param {int} c
 * @returns
 */
function compareVersionJDAPP(a, b, c) {
  let arr;
  const UA = ua;
  try {
    if (UA.indexOf('jdapp;android;') !== -1) {
      arr = UA.substring(UA.indexOf('jdapp;android;') + 14, UA.indexOf('jdapp;android;') + 19).split('.');
    } else if (UA.indexOf('jdapp;iPhone;') !== -1) {
      arr = UA.substring(UA.indexOf('jdapp;iPhone;') + 13, UA.indexOf('jdapp;iPhone;') + 18).split('.');
    } else {
      return false;
    }

    if (arr && arr.length === 3) {
      const cu = arr.join('') * 1 || -1;
      const input = `${a}${b}${c}` * 1;

      if (input > cu) {
        return false;
      }
    } else {
      return false;
    }
  } catch (e) {
    return false;
  }
  return true;
}

/*
* 版本号比较方法
* 传入两个字符串，当前版本号：curV；比较版本号：reqV
* 调用方法举例：compare("1.1","1.2")，将返回false
*/
function compareVersion(curV, reqV) {
  if (curV === reqV) {
    return true;
  }

  if (curV && reqV) {
    // 将两个版本号拆成数字
    // eslint-disable-next-line prefer-const
    const arr1 = curV.split('.');
    // eslint-disable-next-line prefer-const
    const arr2 = reqV.split('.');
    // eslint-disable-next-line prefer-const
    const minLength = Math.min(arr1.length, arr2.length);
    let position = 0;
    let diff = 0;
    // 依次比较版本号每一位大小，当对比得出结果后跳出循环（后文有简单介绍）
    // eslint-disable-next-line no-cond-assign
    while (position < minLength && (diff = parseInt(arr1[position]) - parseInt(arr2[position])) === 0) {
      // eslint-disable-next-line no-plusplus
      position += 1;
    }

    diff = diff !== 0 ? diff : arr1.length - arr2.length;
    // 若curV大于reqV，则返回true
    return diff > 0;
  }
  // 输入为空
  // console.log("版本号不能为空");
  return false;
}

/**
 * pm: 尹飞凡
 * author： 李崇
 * 判断是否要支持商城ios降级所有金融的入口
 *
 * 只有在后台开启开关  并且  当前商城ios版本在配置的区间（或者等于开始或者结束版本）  并且  开始版本不能大于结束版本才会启用
 *
 *  注：
 * 不支持android降级
 * 必须在后台开启版本降级开关
 * 版本区间必须填写正确
 * 填写错误的话，默认全部不开启
 * 获取商城版本号每位都必须是个位的，如果是 4.10.1这样就不行
 *
 * 测试方法： 参数分别是 当前版本，开始版本，结束版本
 * uabrowser.jdAppDemotion('6.5.0','6.5.0','9.0.0') // true
 * uabrowser.jdAppDemotion('9.0.0','6.5.0','9.0.0') // true
 * uabrowser.jdAppDemotion('9.0.1','6.5.0','9.0.0') // false
 *
 *
 * @returns {boolean}  true : 要降级， false： 不降级
 * 目前里面的三个参数是作测试用的，在实际应用中不要传任何参数
 */
function rangeAppVersion(cur, start, end) {
  let currentVersion;
  let startVersion;
  let endVersion;
  const UA = ua;
  try {
    if (UA.indexOf('jdapp;android;') !== -1) {
      // currentVersion = UA.substring(UA.indexOf('jdapp;android;') + 14, UA.indexOf('jdapp;android;') + 19);
      return false; // androis不降级，直接返回false
    } else if (UA.indexOf('jdapp;iPhone;') !== -1) {
      currentVersion = UA.substring(UA.indexOf('jdapp;iPhone;') + 13, UA.indexOf('jdapp;iPhone;') + 18);
    } else {
      return false;
    }

    if (window.data_source_100000175 && window.data_source_100000175.version_range && window.data_source_100000175.version_range.open_demotion === true) {
      startVersion = window.data_source_100000175.version_range.start;
      endVersion = window.data_source_100000175.version_range.end;

      if (!startVersion || startVersion === '' || !endVersion || endVersion === '') {
        return false;
      }

      // TODO: 这个只是为了作单测使用的， 生产环境不生效
      // if (location.origin.indexOf('m.jr.jd.com') < 0 && cur && start && end) {
      if (cur && start && end) {
        currentVersion = cur;
        startVersion = start;
        endVersion = end;
      }

      const startCompare = compareVersion(currentVersion, startVersion);
      const endCompare = compareVersion(endVersion, currentVersion);

      if (startCompare === true && endCompare === true) {
        return true;
      }
      return false;
    }
  } catch (e) {
    return false;
  }
  return false;
}

/**
 * 此函数仅供测试时使用
 * @param cur
 * @param start
 * @param end
 * @returns {boolean}
 */
function rangeAppVersionDev(cur, start, end) {
  let currentVersion;
  let startVersion;
  let endVersion;
  const UA = ua;
  try {
    if (UA.indexOf('jdapp;android;') !== -1) {
      // currentVersion = UA.substring(UA.indexOf('jdapp;android;') + 14, UA.indexOf('jdapp;android;') + 19);
      return false; // androis不降级，直接返回false
    } else if (UA.indexOf('jdapp;iPhone;') !== -1) {
      currentVersion = UA.substring(UA.indexOf('jdapp;iPhone;') + 13, UA.indexOf('jdapp;iPhone;') + 18);
    } else {
      return false;
    }

    console.log(`当前获取到降级接口是否启用：${window.data_source_100000345.version_range.open_demotion}`);

    if (window.data_source_100000345 && window.data_source_100000345.version_range && window.data_source_100000345.version_range.open_demotion === true) {
      startVersion = window.data_source_100000345.version_range.start;
      endVersion = window.data_source_100000345.version_range.end;

      if (!startVersion || startVersion === '' || !endVersion || endVersion === '') {
        return false;
      }

      // TODO: 这个只是为了作单测使用的， 生产环境不生效
      // if (location.origin.indexOf('m.jr.jd.com') < 0 && cur && start && end) {
      if (cur && start && end) {
        currentVersion = cur;
        startVersion = start;
        endVersion = end;
      }

      const startCompare = compareVersion(currentVersion, startVersion);
      const endCompare = compareVersion(endVersion, currentVersion);

      console.log(`当前商城版本是：${currentVersion}`);
      console.log(`当前获取到降级接口start版本：${startVersion}`);
      console.log(`当前获取到降级接口end版本：${endVersion}`);

      if (startCompare === true && endCompare === true) {
        return true;
      }
      return false;
    }
  } catch (e) {
    return false;
  }
  return false;
}

uabrowser.compareVersion = compareVersion;

uabrowser.compareVersionJDAPP = compareVersionJDAPP;

// 是否开启区间版本降级
uabrowser.jdAppDemotion = rangeAppVersion;

uabrowser.jdAppDemotionDev = rangeAppVersionDev;

// 检查微信小程序
try {
  // web-view下的页面内
  // eslint-disable-next-line no-inner-declarations
  function wxReady() {
    uabrowser.isMiniProgram = window.__wxjs_environment === 'miniprogram';
  }

  if (!window.WeixinJSBridge || !window.WeixinJSBridge.invoke) {
    document.addEventListener('WeixinJSBridgeReady', wxReady, false);
  } else {
    wxReady();
  }
} catch (e) {
  console.log(e);
}

uabrowser.getEnv = function() {
  let name = 'other';
  let version = uabrowser.clientVersion;
  if (uabrowser.jdjrPure && uabrowser.kepler) {
    name = 'jdjr-kepler';
  } else if (uabrowser.jdjr) {
    name = 'jdjr';
  } else if (uabrowser.jdjrOld) {
    name = 'jdjr-old';
  } else if (uabrowser.jdapp && !uabrowser.freshApp) {
    name = 'jdapp';
    try {
      const splits = uaLower.split(';');
      // eslint-disable-next-line prefer-destructuring
      version = splits[2] || '';
    } catch (error) {
      console.log(error);
    }
  } else if (uabrowser.weixin) {
    name = 'weixin';
    try {
      const splits = uaLower.split(' ');
      splits.forEach(item => {
        if (item && item.indexOf('micromessenger') > -1) {
          // eslint-disable-next-line prefer-destructuring
          version = item.split('/')[1] || '';
        }
      });
    } catch (error) {
      console.log(error);
    }
  } else if (uabrowser.jdlocal) {
    name = 'jdlocal';
  } else if (uabrowser.freshApp) {
    name = '7fresh';
  } else if (uabrowser.qq) {
    name = 'qq';
  }

  return { name, version, osVersion: uabrowser.osVersion };
};

export default uabrowser;
