<template>
  <div class="command-success modal-box">
    <div class="command-success-body">
        <div class="command-success-title">金口令已经复制</div>
        <div class="command-success-desc">{{copySuccessText}}</div>
        <a class="command-success-btn" :clstag="clstag" @click="hide" href="javascript:window.location.href='weixin://';">去<span></span>微信粘贴给好友</a>
        <div class="command-success-icon"></div>
        <div class="modal-close" @click="hide"></div>
    </div>
  </div>
</template>
<script>
import jrJsBridge from './jrJsBridge';  // 金融jsBridge文件
import uabrowser from './uabrowser';  // 运行环境判断文件
const jrBridgeDefer = jrJsBridge.onReady()
export default {
  props: {
    copySuccessText: { // 复制成功后弹出的提示信息
      default: ''
    },
    copyMessage: {   // 复制到剪切板上的信息
      default: ''
    },
    clstag: { // 点击去微信粘贴好友的埋点信息
      default: ''
    }
  },
  data() {
    return {
      
    };
  },
  created() {
    this.copyText();
  },
  mounted(){
    console.log(this.$copyText,this.copyMessage);
  },
  destroyed() {},
  methods: {
    hide(){
        this.$emit('close');
    },
    copyText: async function() {
      if (uabrowser.jdjr) {
        // 如果在金融APP站内则利用JS桥进行复制
        try {
          jrBridgeDefer.then(res => {
              res.jsToGetResp(d => {
                  d = typeof d === 'object' ? d : JSON.parse(d);
                  if (d && d.type === '27') {
                    // alert('1212 -> ' + JSON.stringify(d));
                    // 业务逻辑
                  }
                },
                {
                  type: '27',
                  boardText: this.copyMessage
                }
              );
            });
        } catch (e) {
            this.$copyText(this.copyMessage).then(
            function(e) {
              console.log(e);
            },
            function(e) {
              console.log(e);
            }
          );
        } 
      } else {
        this.$copyText(this.copyMessage).then(
          function(e) {
            console.log(e);
          },
          function(e) {
            console.log(e);
          }
        );
      }
    }
  }
};
</script>

<style lang="scss">
@import './command-copy.scss';
</style>
